﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    public static GameManager instance;
    public GameObject gameOverText;
    public GameObject menuButton;
    public GameObject resumeButton;
    public GameObject replayButton;
    public GameObject player;
    public GameObject spawner;
    public Text pointsText;

	// Use this for initialization
	void Awake ()
    {
        if(instance == null)
        {
            instance = this;
        }
        else if(instance != null)
        {
            Destroy(gameObject);
        }
        init();
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}

    void init()
    {
        gameOverText.SetActive(false);
        resumeButton.SetActive(false);
        replayButton.SetActive(false);
    }

    public void OnPause()
    {
        menuButton.SetActive(false);
        resumeButton.SetActive(true);
        replayButton.SetActive(true);
        Time.timeScale = 0;
    }

    public void OnResume()
    {
        resumeButton.SetActive(false);
        replayButton.SetActive(false);
        menuButton.SetActive(true);
        Time.timeScale = 1;
    }

    public void OnReplay()
    {
        Time.timeScale = 1;
        Application.LoadLevel(Application.loadedLevel);
    }

    public void SetPoints(int pts)
    {
        pointsText.text = "Points: " + pts;
    }

    public void GameOver()
    {
        replayButton.SetActive(true);
        gameOverText.SetActive(true);
        Destroy(player.gameObject);
        Destroy(spawner.gameObject);
    }
}
