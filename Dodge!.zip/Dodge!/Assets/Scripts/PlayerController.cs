﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

    public float minValue = -5.0f;
    public float maxValue = 5.0f;
    public float direction = 1;
    public float maxSpeed = 10.0f;
    public float minSpeed = 2.0f;

    private float speed;
    private float currentValue;

	// Use this for initialization
	void Start ()
    {
        speed = maxSpeed;
	}
	
	// Update is called once per frame
	void Update ()
    {
        if(Input.GetMouseButtonDown(0))
        {
            speed = minSpeed;
        }
        else if(Input.GetMouseButtonUp(0))
        {
            speed = maxSpeed;
        }

        currentValue = currentValue + (Time.deltaTime * direction * speed);
        
        if(currentValue >= maxValue)
        {
            direction = direction * -1;
            currentValue = maxValue;
        }
        else if(currentValue <= minValue)
        {
            direction = direction * -1;
            currentValue = minValue;
        }

        transform.position = new Vector2(transform.position.x, currentValue);
	}
}