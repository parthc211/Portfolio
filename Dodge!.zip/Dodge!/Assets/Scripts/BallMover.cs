﻿using UnityEngine;
using System.Collections;

public class BallMover : MonoBehaviour {

    public float ballSpeed = 20.0f;

    private static int points = 0;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update ()
    {
        Vector2 move = transform.right * Time.deltaTime * ballSpeed;

        transform.Translate(move);
	}

    void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject);
            GameManager.instance.GameOver();
            points = 0;
            Debug.Log("GAME OVER!");
        }

        if(other.gameObject.CompareTag("Barrier"))
        {
            Destroy(gameObject);
            points++;
            GameManager.instance.SetPoints(points);
            Debug.Log(points);
        }
    }
}
