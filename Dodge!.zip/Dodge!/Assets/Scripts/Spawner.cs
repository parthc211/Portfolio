﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour {

    private Vector2 startPos;

    public GameObject ball;
    public float minTime = 1.0f;
    public float maxTime = 3.0f;

	// Use this for initialization
	void Start () {
        startPos = transform.position;

        Spawn();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void Spawn()
    {
        Vector2 newPos = startPos + new Vector2(startPos.x, Random.Range(-4.0f, 4.0f));
        GameObject clone = (GameObject)Instantiate(ball, newPos, Quaternion.identity);
        clone.transform.parent = transform;

        Invoke("Spawn", Random.Range(minTime, maxTime));
    }
}
