﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovementScript : MonoBehaviour {

    public float moveSpeed = 3.0f;
    public float wallCheckRadius;
    public bool facingRight;
    public Transform wallCheck;
    public Transform edgeCheck;
    public LayerMask wall;

    private bool hitWall;
    private bool atEdge;
    private Rigidbody2D rigid;

    private void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
    }

    void Update ()
    {
        hitWall = Physics2D.OverlapCircle(wallCheck.position, wallCheckRadius, wall);
        atEdge = Physics2D.OverlapCircle(edgeCheck.position, wallCheckRadius, wall);

        if(hitWall || !atEdge)
        {
            facingRight = !facingRight;
        }

        if (facingRight)
        {
            transform.localScale = new Vector3(-1.0f, 1.0f, 1.0f);
            rigid.velocity = new Vector2(moveSpeed, rigid.velocity.y);
        }
        else if (!facingRight)
        {
            transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            rigid.velocity = new Vector2(-moveSpeed, rigid.velocity.y);
        }
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            PlayerHealthScript.health.ReduceHealth();
        }
    }
}
