﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrickPlatfrom : MonoBehaviour {

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.collider.CompareTag("Player"))
        {
            Invoke("PlatformDestroy", 1);
        }
    }

    void PlatformDestroy()
    {
        Destroy(gameObject);
    }
}
