﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour {

    public PlayerControllerScript thePlayer;
    public PlayerHealthScript playerHealth;

    private void Awake()
    {
        thePlayer = FindObjectOfType<PlayerControllerScript>();
        playerHealth = FindObjectOfType<PlayerHealthScript>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //if(collision.collider.CompareTag("Player"))
        //{
        //    thePlayer.knockbackCount = thePlayer.knockbackLength;

        //    if (collision.collider.transform.position.x < transform.position.x)
        //        thePlayer.knockFromRight = true;
        //    else
        //        thePlayer.knockFromRight = false;
        //}

        if(collision.collider.CompareTag("Player"))
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            thePlayer.knockbackCount = thePlayer.knockbackLength;

            if (collision.transform.position.x < transform.position.x)
                thePlayer.knockFromRight = true;
            else
                thePlayer.knockFromRight = false;
        }
    }
}
