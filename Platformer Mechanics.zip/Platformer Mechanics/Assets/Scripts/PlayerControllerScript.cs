﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControllerScript : MonoBehaviour {

    public float maxSpeed = 10.0f;
    public float jumpForce = 700.0f;
    public float playerClimbSpeed = 4.0f;
    public float springBoardForce = 1000.0f;
    public float knockback;
    public float knockbackLength;
    public float knockbackCount;
    public Transform groundCheck;
    public LayerMask ground;
    public bool onLadder;
    public bool onMovingPlatform;
    public bool knockFromRight;

    private Rigidbody2D rb2D;
    private bool grounded = false;
    private bool doubleJump = false;
    private bool running = false;
    private bool onMud = false;
    private float groundRadius = 0.2f;
    private float climbVelocity;
    private float gravityOnPlayer;

	void Start ()
    {
        rb2D = GetComponent<Rigidbody2D>();

        gravityOnPlayer = rb2D.gravityScale;
	}
    void Update()
    {
        if (!onMud)
        {
            if ((grounded || !doubleJump) && Input.GetKeyDown(KeyCode.Space))
            {
                rb2D.velocity = new Vector2(rb2D.velocity.x, 0);

                rb2D.AddForce(new Vector2(0, jumpForce));
                if (!doubleJump && !grounded)
                {
                    doubleJump = true;
                }
            } 
        }

        if (Input.GetKey(KeyCode.LeftControl) && !onMud)
        {
            running = true;
        }
        else
        {
            running = false;
        }

        if (onLadder)
        {
            rb2D.gravityScale = 0.0f;

            climbVelocity = playerClimbSpeed * Input.GetAxis("Vertical");

            rb2D.velocity = new Vector2(rb2D.velocity.x, climbVelocity);
        }
        
        if(!onLadder)
        {
            rb2D.gravityScale = gravityOnPlayer;
        }
    }

    void FixedUpdate ()
    {
        grounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, ground);

        if(grounded)
        {
            doubleJump = false;
        }

        //if (!grounded)          //remove this if statement to move around in mid-air
        //    return;

        float move = Input.GetAxis("Horizontal");

        if (knockbackCount <= 0)
        {
            if (running)
            {
                rb2D.velocity = new Vector2(move * maxSpeed * 2, rb2D.velocity.y);
            }
            else if (onMud)
            {
                rb2D.velocity = new Vector2(move * maxSpeed * .2f, 0);
            }
            else
            {
                rb2D.velocity = new Vector2(move * maxSpeed, rb2D.velocity.y);
            }
        }
        else
        {
            if(knockFromRight)
            {
                rb2D.velocity = new Vector2(-knockback, knockback);
            }
            if(!knockFromRight)
            {
                rb2D.velocity = new Vector2(knockback, knockback);
            }
            knockbackCount -= Time.deltaTime;
        }
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.transform.CompareTag("MovingPlatform"))
        {
            onMovingPlatform = true;
            transform.parent = collision.transform;
        }

        if(collision.collider.CompareTag("SpringBoard"))
        {
            rb2D.AddForce(new Vector2(0, springBoardForce));
        }
        if(collision.collider.CompareTag("Mud"))
        {
            onMud = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if(collision.transform.CompareTag("MovingPlatform"))
        {
            onMovingPlatform = false;
            transform.parent = null;
        }
        if(collision.collider.CompareTag("Mud"))
        {
            onMud = false;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("DeathZone"))
        {
            PlayerHealthScript.health.Kill();
        }

        if(collision.CompareTag("Finished"))
        {
            PlayerHealthScript.health.Reload();
        }
    }
}
