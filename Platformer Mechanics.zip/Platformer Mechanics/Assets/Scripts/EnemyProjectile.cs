﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProjectile : MonoBehaviour {

    public float distance;
    public float shootingTime = 0.5f;
    public GameObject bullet;
    public Transform shootingPoint;

    private PlayerControllerScript player;
    private float distanceRemaining;
    private float distanceY;
    private float nextShot;

    private void Awake()
    {
        player = FindObjectOfType<PlayerControllerScript>();
    }

    private void Update()
    {
        if (player == null)
            return;

        distanceRemaining = transform.position.x - player.transform.position.x;
        distanceY = Mathf.Abs(player.transform.position.y - transform.position.y);

        if ((distanceRemaining < distance) && (distanceRemaining >= -1) && (distanceY < 2))
        {
            Shoot();
        }
        nextShot -= Time.deltaTime;
    }

    void Shoot()
    {
        if(nextShot <= 0)
        {
            Instantiate(bullet, shootingPoint.position, Quaternion.identity);
            nextShot = shootingTime;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            PlayerHealthScript.health.ReduceHealth();
        }
    }
}
