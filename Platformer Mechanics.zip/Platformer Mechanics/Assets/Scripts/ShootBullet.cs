﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShootBullet : MonoBehaviour {

    public float shootingSpeed = 20.0f;

    private Rigidbody2D rbBullet;

	void Start ()
    {
        rbBullet = GetComponent<Rigidbody2D>();
	}
	
	void Update ()
    {
        rbBullet.velocity = new Vector2(-shootingSpeed, rbBullet.velocity.y);
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            Destroy(gameObject);
            PlayerHealthScript.health.ReduceHealth();
        }
    }
}
