﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealthScript : MonoBehaviour {

    public int playerHealth = 5;

    public static PlayerHealthScript health = null;

    private void Start()
    {
        if(health == null)
        {
            health = this;
        }
        else if(health != null)
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        GameManager.instance.UpdateHealthText();

        if(playerHealth <= 0)
        {
            Kill();
        }
    }

    public void ReduceHealth()
    {
        playerHealth--;
        Debug.Log("Health: " + playerHealth);
    }
    public void Kill()
    {
        Destroy(gameObject);
        Reload();
    }

    public void Reload()
    {
        SceneManager.LoadScene(0);
    }
}
