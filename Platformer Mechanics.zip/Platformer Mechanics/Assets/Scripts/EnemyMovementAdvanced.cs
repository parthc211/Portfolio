﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovementAdvanced : MonoBehaviour {

    public float moveSpeed = 3.0f;
    public float chargeSpeed = 10.0f;
    public float wallCheckRadius;
    public bool facingRight;
    public Transform wallCheck;
    public Transform edgeCheck;
    public LayerMask wall;
    public float distance = 10.0f;

    private float distanceRemaining;
    private float inputSpeed;
    private float distanceY;
    private bool hitWall;
    private bool atEdge;
    private Rigidbody2D rigid;
    private PlayerControllerScript player;

    private void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
        player = FindObjectOfType<PlayerControllerScript>();
    }

    void Update()
    {
        hitWall = Physics2D.OverlapCircle(wallCheck.position, wallCheckRadius, wall);
        atEdge = Physics2D.OverlapCircle(edgeCheck.position, wallCheckRadius, wall);

        if (player == null)
            return;

        distanceRemaining = Mathf.Abs(player.transform.position.x - transform.position.x);
        distanceY = Mathf.Abs(player.transform.position.y - transform.position.y);


        if((distanceRemaining < distance) && (distanceY < 2))
        {
            inputSpeed = chargeSpeed;
        }
        else
        {
            inputSpeed = moveSpeed;
        }


        if (hitWall || !atEdge)
        {
            facingRight = !facingRight;
        }

        if (facingRight)
        {
            transform.localScale = new Vector3(-1.0f, 1.0f, 1.0f);
            rigid.velocity = new Vector2(inputSpeed, rigid.velocity.y);
        }
        else if (!facingRight)
        {
            transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            rigid.velocity = new Vector2(-inputSpeed, rigid.velocity.y);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            PlayerHealthScript.health.ReduceHealth();
        }
    }
}