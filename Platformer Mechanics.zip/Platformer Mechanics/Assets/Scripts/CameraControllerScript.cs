﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControllerScript : MonoBehaviour {

    public bool isFollowing;
    public float xOffset;
    public float yOffset;


    private PlayerControllerScript thePlayer;

    private Vector3 lastPlayerPosition;
    private float distanceToMove;
    private float yRange;

    private void Start()
    {
        thePlayer = FindObjectOfType<PlayerControllerScript>();
        lastPlayerPosition = thePlayer.transform.position;
        isFollowing = true;
    }

    private void Update()
    {
        if (thePlayer == null)
            return;

        distanceToMove = thePlayer.transform.position.x - lastPlayerPosition.x;

        if(distanceToMove > 0)
        {
            if(thePlayer.transform.position.y < -10)
            {
                transform.position = new Vector3(transform.position.x + distanceToMove + xOffset, -10 + yOffset, transform.position.z);
            }
            else
            {
                transform.position = new Vector3(transform.position.x + distanceToMove + xOffset, thePlayer.transform.position.y + yOffset, transform.position.z);
            }
            lastPlayerPosition = thePlayer.transform.position;
        }
        else
        {
            if (thePlayer.transform.position.y < -10)
            {
                transform.position = new Vector3(transform.position.x + xOffset, -10 + yOffset, transform.position.z);
            }
            else
            {
                transform.position = new Vector3(transform.position.x + xOffset, thePlayer.transform.position.y + yOffset, transform.position.z);
            }
            //lastPlayerPosition = thePlayer.transform.position;
        }
    }
}
