﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatfromPlayerOn : MonoBehaviour {

	public GameObject platform;
    public float moveSpeed;
    public Transform[] points;
    public int pointSelection;

    private Transform currentPoint;
    private PlayerControllerScript playerControl;

    private void Awake()
    {
        playerControl = FindObjectOfType<PlayerControllerScript>();
    }

    private void Start()
    {
        currentPoint = points[pointSelection];
    }

    private void Update()
    {
        if (playerControl.onMovingPlatform)
        {
            platform.transform.position = Vector3.MoveTowards(platform.transform.position, currentPoint.position, Time.deltaTime * moveSpeed);

            if (platform.transform.position == currentPoint.position)
            {
                pointSelection++;

                if (pointSelection == points.Length)
                {
                    pointSelection = 0;
                }

                currentPoint = points[pointSelection];
            } 
        }
    }
}
