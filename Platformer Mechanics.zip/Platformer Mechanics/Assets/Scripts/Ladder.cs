﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ladder : MonoBehaviour {

    private PlayerControllerScript player;

	// Use this for initialization
	void Start () {
        player = FindObjectOfType<PlayerControllerScript>();
	}

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            player.onLadder = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            player.onLadder = false;
        }
    }
}
