﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    public float speed = 10.0f;
    public float jumpSpeed = 20f;
    public bool grounded = true;

    private bool touchingPlatform;
    private Rigidbody rb;
    private bool jumping;

    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();
    }

    void Update()
    {
        Vector3 x = Input.GetAxis("Horizontal") * transform.right * Time.deltaTime * speed;
        Vector3 z = transform.forward * Time.deltaTime * speed;

        transform.Translate(x + z);
        transform.rotation = Quaternion.LookRotation(Vector3.forward);

        if(Input.GetButtonDown("Jump"))
        {
            Jump();
        }
    }

    void Jump()
    {
        if(grounded == true)
        {
            rb.AddForce(Vector3.up * jumpSpeed);
            grounded = false;
        }
    }

    void OnCollisionEnter(Collision other)
    {
        grounded = true;
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.CompareTag("Obstacle") || other.gameObject.CompareTag("DeadZone"))
        {
            Application.LoadLevel(Application.loadedLevel);
        }
    }
}