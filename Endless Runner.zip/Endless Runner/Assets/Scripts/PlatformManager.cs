﻿using UnityEngine;
using System.Collections;

public class PlatformManager : MonoBehaviour {

    public int maxPlatforms = 20;
    public GameObject platform;
    [HideInInspector] public int platformCount;
    public int delay = 5;

    private Vector3 originPosition = Vector3.zero;

	// Use this for initialization
	void Start ()
    {
        Instantiate(platform, originPosition , Quaternion.identity);
        originPosition = transform.position;
        //Spwan();
    }
	
	// Update is called once per frame
	void Update ()
    {
        //Invoke("Spwan", delay);
        Vector3 newPosition = originPosition + new Vector3(0.0f, 0.0f, 20.0f);
        GameObject clone = (GameObject)Instantiate(platform, newPosition, Quaternion.identity);
        originPosition = newPosition;

        clone.transform.parent = transform;
    }

    void Spwan()
    {
        for (platformCount = 0; platformCount < maxPlatforms; platformCount++)
        {
            Vector3 newPosition = originPosition + new Vector3(0.0f, 0.0f, 20.0f);
            GameObject clone = (GameObject)Instantiate(platform, newPosition, Quaternion.identity);
            originPosition = newPosition;

            clone.transform.parent = transform;
        }
    }
}