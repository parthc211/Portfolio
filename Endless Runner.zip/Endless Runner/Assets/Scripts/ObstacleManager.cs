﻿using UnityEngine;
using System.Collections;

public class ObstacleManager : MonoBehaviour {

    public GameObject obstacle;
    //public float randomWidth = 10.0f;
    //public float randomHeight = 2.0f;
    public int maxObstacle = 20;
    [HideInInspector] public int obstacleCount;
    
    private Vector3 originPosition = new Vector3(0f, 1f, -1f);

	// Use this for initialization
	void Start ()
    {
        SpwanObstacle();
	}
	
	// Update is called once per frame
	void Update ()
    {
        Vector3 newPosition = originPosition + new Vector3(Random.Range(-2f, 2f), 0f, Random.Range(8f, 10f));
        float xNew = newPosition.x;
        GameObject clone = (GameObject)Instantiate(obstacle, newPosition, Quaternion.identity);
        originPosition = newPosition - new Vector3(xNew, 0f, 0f);

        clone.transform.parent = transform;
    }

    void SpwanObstacle()
    {
        for (obstacleCount = 0; obstacleCount < maxObstacle; obstacleCount++)
        {
            Vector3 newPosition = originPosition + new Vector3(Random.Range(-2f, 2f), 0f, 10f);
            float xNew = newPosition.x;
            GameObject clone = (GameObject)Instantiate(obstacle, newPosition, Quaternion.identity);
            originPosition = newPosition - new Vector3(xNew, 0f, 0f);

            clone.transform.parent = transform;
        }
    }
}
