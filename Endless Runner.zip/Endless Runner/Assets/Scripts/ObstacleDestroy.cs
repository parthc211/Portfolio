﻿using UnityEngine;
using System.Collections;

public class ObstacleDestroy : MonoBehaviour {

    private Transform findPlayer;

    private Vector3 obstaclePosition;

	// Use this for initialization
	void Start ()
    {
        findPlayer = GameObject.FindGameObjectWithTag("Player").transform;
        obstaclePosition = transform.position;
	}
	
	// Update is called once per frame
	void Update ()
    {
	    if(transform.position.z < findPlayer.position.z)
        {
            Destroy(gameObject, 1.0f);
        }
	}
}
