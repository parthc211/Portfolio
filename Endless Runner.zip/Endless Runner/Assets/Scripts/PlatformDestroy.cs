﻿using UnityEngine;
using System.Collections;

public class PlatformDestroy : MonoBehaviour {

    public float exitAfterSeconds = 10f;
    public bool dest;
    private float targetTime;

	// Use this for initialization
	void Start ()
    {

	}
	
	// Update is called once per frame
	void Update ()
    {
	    if(dest)
        {
            Destroy(gameObject, exitAfterSeconds);
        }
	}

    void OnCollisionEnter(Collision other)
    {
        dest = true;
    }
}
