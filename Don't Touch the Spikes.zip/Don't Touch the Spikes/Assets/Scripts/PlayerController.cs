﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	private Rigidbody2D rb2D;
	private bool leftRight = true;
	private int points;

	public GameObject[] spikesRight;
	public GameObject[] spikesLeft;
	public float jumpSpeed = 10.0f;
	public float sideSpeed = 5.0f;

	void Start () 
	{
		rb2D = GetComponent<Rigidbody2D> ();

		for(int x = 0; x < spikesRight.Length; x++)
		{
			spikesRight [x].SetActive (false);
		}

		for(int x = 0; x < spikesLeft.Length; x++)
		{
			spikesLeft [x].SetActive (false);
		}
	}
	
	void Update () 
	{
		if (Input.GetMouseButtonDown(0))
		{
			if (Time.timeScale == 0) 
			{
				Time.timeScale = 1;
			}
			if (leftRight == true) {
				rb2D.velocity = new Vector2 (sideSpeed, jumpSpeed);
			}
			else if (leftRight == false)
			{
				rb2D.velocity = new Vector2 (-sideSpeed, jumpSpeed);
			}
		}
	}

	void OnCollisionEnter2D(Collision2D other)
	{
		if(other.gameObject.CompareTag("Spike"))
		{
			GameManager.instance.GameOver ();
			return;
		}
		if (leftRight) 
		{
			for(int x = 0; x < spikesRight.Length; x++)
			{
				spikesRight [x].SetActive (false);
			}

			for (int i = 0; i <= (int)Random.Range(6.0f, 8.0f); i++) 
			{
				float randnum = Random.Range (0, 7);
				int spikenum = (int)randnum;
				spikesLeft [spikenum].SetActive (true);
			}
		} 
		else if(leftRight == false)
		{
			for(int x = 0; x < spikesLeft.Length; x++)
			{
				spikesLeft [x].SetActive (false);
			}

			for (int i = 0; i <= (int)Random.Range(6.0f, 8.0f); i++) 
			{
				float randnum = Random.Range (0, 7);
				int spikenum = (int)randnum;
				spikesRight [spikenum].SetActive (true);
			}
		}

		leftRight = !leftRight;

		points++;
		GameManager.instance.SetPoints (points);
		}
}