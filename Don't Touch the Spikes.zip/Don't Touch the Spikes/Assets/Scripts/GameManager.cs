﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

	public static GameManager instance;
	public Text points;
	public GameObject menuButton;
	public GameObject resumeButton;
	public GameObject replayButton;
	public GameObject player;
	public GameObject gameOver;
	public GameObject playButton;
	public GameObject[] spikes;
	public GameObject borders;
	public GameObject pointsObject;

	void Awake () 
	{
		if (instance == null) 
		{
			instance = this;
		}
		else if (instance != null) 
		{
			Destroy (gameObject);
		}

		init ();
	}
	
	void init()
	{
		menuButton.SetActive (false);
		replayButton.SetActive(false);
		resumeButton.SetActive(false);
		gameOver.SetActive(false);
		player.SetActive (false);
		borders.SetActive (false);
		pointsObject.SetActive (false);
		for (int i = 0; i < spikes.Length; i++) 
		{
			spikes [i].SetActive (false);
		}

		playButton.SetActive (true);
	}

	public void GameOver()
	{
		gameOver.SetActive(true);
		replayButton.SetActive(true);
		menuButton.SetActive(false);
		player.gameObject.SetActive(false);
	}

	public void SetPoints(int pts)
	{
		points.text = "Points: " + pts;
	}

	public void Replay()
	{
		Time.timeScale = 1;
		Application.LoadLevel(Application.loadedLevel);
	}

	public void OnPause()
	{
		menuButton.SetActive(false);
		resumeButton.SetActive(true);
		replayButton.SetActive(true);
		Time.timeScale = 0;
	}

	public void OnResume()
	{
		replayButton.SetActive(false);
		resumeButton.SetActive(false);
		menuButton.SetActive(true);
		Time.timeScale = 1;
	}

	public void PlayButton()
	{
		replayButton.SetActive (false);
		resumeButton.SetActive (false);
		gameOver.SetActive (false);
		playButton.SetActive (false);

		player.SetActive (true);
		menuButton.SetActive (true);
		borders.SetActive (true);
		pointsObject.SetActive (true);
		for (int i = 0; i < spikes.Length; i++) 
		{
			spikes [i].SetActive (true);
		}

		Time.timeScale = 0;
	}
}