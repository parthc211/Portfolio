﻿using UnityEngine;
using System.Collections;

public class ObstacleSpawner : MonoBehaviour{

    public GameObject obstacle;

    private Vector2 originPosition = new Vector2(0f, 0f);

    void Update()
    {
        Spawn();
    }

    void Spawn()
    {
        Vector2 newPosition = originPosition + new Vector2(Random.Range(-6.0f, 6.0f), Random.Range(5.0f, 6.0f));
        GameObject clone = (GameObject)Instantiate(obstacle, newPosition, Quaternion.identity);
        float xNew = newPosition.x;
        originPosition = newPosition - new Vector2(xNew, 0);

        clone.transform.parent = transform;
    }
}