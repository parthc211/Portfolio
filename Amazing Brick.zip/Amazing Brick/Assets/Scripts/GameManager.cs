﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    public static GameManager instance = null;
    public GameObject gameOver;
    public GameObject spawner;
    public GameObject player;
    public GameObject replayButton;
    public GameObject resumeButton;
    public GameObject menuButton;
    public bool over;
    public Text highScoreText;
    
        
	void Awake ()
    {
        if (instance == null)
            instance = this;
        else if (instance != null)
            Destroy(gameObject);

        init();
	}

    public void GameOver()
    {
        gameOver.SetActive(true);
        replayButton.SetActive(true);
        menuButton.SetActive(false);
        spawner.gameObject.SetActive(false);
        player.gameObject.SetActive(false);
        //Destroy(spawner.gameObject);
        //Destroy(player.gameObject);
        over = true;
    }

    public void init()
    {
        over = false;
        replayButton.SetActive(false);
        resumeButton.SetActive(false);
        gameOver.SetActive(false);
        spawner.gameObject.SetActive(true);
        player.gameObject.SetActive(true);
        SetHighScoreText();
    }

    public void Replay()
    {
        Time.timeScale = 1;
        Application.LoadLevel(Application.loadedLevel);
    }

    public void SetHighScoreText()
    {
        highScoreText.text = "High Score: " + PlayerPrefs.GetInt("High Score");
    }

    public void OnPause()
    {
        menuButton.SetActive(false);
        resumeButton.SetActive(true);
        replayButton.SetActive(true);
        Time.timeScale = 0;
    }

    public void OnResume()
    {
        replayButton.SetActive(false);
        resumeButton.SetActive(false);
        menuButton.SetActive(true);
        Time.timeScale = 1;
    }
}
