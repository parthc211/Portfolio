﻿using UnityEngine;
using System.Collections;

public class BarrierDestroy : MonoBehaviour {

    private Transform findPlayer;
    private Vector3 barrierPosition;

	void Start ()
    {
        findPlayer = GameObject.FindGameObjectWithTag("Player").transform;
        barrierPosition = transform.position;
    }
	
	void Update ()
    {
        if (transform.position.y < findPlayer.position.y - 25)
        {
            Destroy(gameObject, 3.0f);
        }
    }
}
