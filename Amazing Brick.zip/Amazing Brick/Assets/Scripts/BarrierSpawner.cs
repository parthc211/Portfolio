﻿using UnityEngine;
using System.Collections;

public class BarrierSpawner : MonoBehaviour {

    public GameObject barrier;

    private Vector2 originPosition = new Vector2(0f, 0f);
	
	void Update ()
    {
        Spawn();
	}

    void Spawn()
    {
        Vector2 newPosition = originPosition + new Vector2(Random.Range(-5.0f, 5.0f), Random.Range(7.0f, 10.0f));
        GameObject clone = (GameObject)Instantiate(barrier, newPosition, Quaternion.identity);
        float xNew = newPosition.x;
        originPosition = newPosition - new Vector2(xNew, 0);

        clone.transform.parent = transform;
    }
}
