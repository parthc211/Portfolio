﻿using UnityEngine;
using System.Collections;

public class ObstacleDestroy : MonoBehaviour {

    private Transform findPlayer;
    private Vector3 obstaclePosition;

    void Start()
    {
        findPlayer = GameObject.FindGameObjectWithTag("Player").transform;
        obstaclePosition = transform.position;
    }
    
    void Update()
    {
        if (transform.position.y < findPlayer.position.y - 25)
        {
            Destroy(gameObject, 3.0f);
        }
    }
}
