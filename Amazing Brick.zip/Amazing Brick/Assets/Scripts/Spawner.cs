﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour {

    public GameObject obstacle;
    public GameObject barrier;

    private Vector2 originPos = new Vector2(0.0f, 0.0f);
    private Vector2 newPos;
    
	void Start () {
        Spawn();
	}

    void Spawn()
    {
        float xNew;

        int x = (int)Random.Range(3, 4);

        for(int i = 0; i <= x; i++)
        {
            newPos = originPos + new Vector2(Random.Range(-4.5f, 4.5f), Random.Range(5.0f, 6.0f));
            GameObject clone = (GameObject)Instantiate(obstacle, newPos, Quaternion.identity);
            xNew = newPos.x;
            originPos = newPos - new Vector2(xNew, 0);

            clone.transform.parent = transform;
        }

        

        newPos = originPos + new Vector2(Random.Range(-3.0f, 3.0f), Random.Range(1.0f, 2.0f));
        GameObject clone1 = (GameObject)Instantiate(barrier, newPos, Quaternion.identity);
        xNew = newPos.x;
        originPos = newPos - new Vector2(xNew, 0);

        clone1.transform.parent = transform;

        Invoke("Spawn", Random.Range(2.0f, 3.0f));
    }
}
