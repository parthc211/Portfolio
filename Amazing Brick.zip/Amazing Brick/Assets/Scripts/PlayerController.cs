﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    public float jumpSpeed = 10.0f;
    public float sideSpeed = 3.0f;
    public Text pointText;
    public GameObject gameOverText;
    
    private int points = 0;
    private Rigidbody2D rb2D;

	void Start ()
    {
        rb2D = GetComponent<Rigidbody2D>();
	}
	
	void Update ()
    {
	    if(Input.GetMouseButtonDown(0))
        {
            if(Input.mousePosition.x >= Screen.width/2)
                rb2D.velocity = new Vector2(sideSpeed, jumpSpeed);

            if (Input.mousePosition.x < Screen.width/2)
                rb2D.velocity = new Vector2(-sideSpeed, jumpSpeed);
        }
    }

    public void setHighScore()
    {
        if(points > PlayerPrefs.GetInt("High Score"))
        {
            PlayerPrefs.SetInt("High Score", points);
            PlayerPrefs.Save();

            Debug.Log("High Score is: " + PlayerPrefs.GetInt("High Score"));
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.CompareTag("Barrier"))
        {
            setHighScore();
            GameManager.instance.SetHighScoreText();
            GameManager.instance.GameOver();
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Destroy(other.gameObject);
        points++;
        pointText.text = "Points: " + points;
    }
}
