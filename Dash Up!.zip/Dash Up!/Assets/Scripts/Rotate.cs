﻿using UnityEngine;
using System.Collections;

public class Rotate : MonoBehaviour {

	public float speed = 10.0f;
	private Vector3 x = new Vector3 (0.0f, 0.0f, 1.0f);

	void Update () 
	{
		transform.Rotate (x, speed * Time.deltaTime);
	}
}
