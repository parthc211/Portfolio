﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour {

    private Vector2 startPos;
	private int objectToSpawn;

    public GameObject[] spawnObjects;

	void Start ()
    {
        startPos = transform.position;

        Spawn();
	}
	
	void Update ()
    {
	
	}

    void Spawn()
    {
		int objectToSpawn = Random.Range (0, spawnObjects.Length);

        Vector2 newPos = startPos + new Vector2(startPos.x, 10.0f);
		GameObject clone = (GameObject)Instantiate(spawnObjects[objectToSpawn], newPos, Quaternion.identity);
        clone.transform.parent = transform;

        startPos = new Vector2(0.0f, newPos.y + 10.0f);

        Invoke("Spawn", 0.5f);
    }
}