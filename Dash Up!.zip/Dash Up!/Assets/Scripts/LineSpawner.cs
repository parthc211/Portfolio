﻿using UnityEngine;
using System.Collections;

public class LineSpawner : MonoBehaviour {

    private Vector2 startPos;

    public GameObject barrier;

	void Start ()
    {
        startPos = transform.position;

		startPos = startPos - new Vector2 (8.0f, 0.0f);

        Spawn();
	}
	
	void Update ()
    {
	
	}

    void Spawn()
    {
        Vector2 newPos = startPos + new Vector2(startPos.x, 0.0f);
        GameObject clone = (GameObject)Instantiate(barrier, newPos, Quaternion.identity);
        clone.transform.parent = transform;

        //startPos = new Vector2(0.0f, newPos.y + 6.0f);

        Invoke("Spawn", 3.0f);
    }
}