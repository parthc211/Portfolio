﻿using UnityEngine;
using System.Collections;

public class LineMover : MonoBehaviour {

	public float speed = 5.0f;

	void Start () 
	{

	}
	
	void Update () 
	{
		transform.Translate (speed * Time.deltaTime, 0.0f, 0.0f);
		Destroy (gameObject, 6.0f);
	}
}
