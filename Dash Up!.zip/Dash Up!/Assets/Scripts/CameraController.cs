﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour
{

    public PlayerController thePlayer;

    private Vector3 lastPlayerPosition;
    private float distanceToMove;

    void Start()
    {
        thePlayer = FindObjectOfType<PlayerController>();
        lastPlayerPosition = thePlayer.transform.position;
    }

    void Update()
    {
        if(GameManager.instance.over)
        {
            return;
        }

        distanceToMove = thePlayer.transform.position.y - lastPlayerPosition.y;

        if (distanceToMove > 0)
        {

            transform.position = new Vector3(transform.position.x, transform.position.y + distanceToMove, transform.position.z);

            lastPlayerPosition = thePlayer.transform.position;
        }
    }
}
