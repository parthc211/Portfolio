﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

    public float jumpSpeed = 30.0f;

    private Rigidbody2D rb2D;
    private int points;

	void Start ()
    {
        rb2D = GetComponent<Rigidbody2D>();
        points = 0;
	}
	
	void Update ()
    {
        if (Input.GetMouseButtonDown(0))
        {
            rb2D.velocity = new Vector2(0.0f, jumpSpeed);
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Barrier"))
        {
            //Time.timeScale = 0;
            GameManager.instance.GameOver();
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        points++;
        GameManager.instance.SetPoints(points);
        Destroy(other.gameObject);
        Debug.Log(points);
    }
}