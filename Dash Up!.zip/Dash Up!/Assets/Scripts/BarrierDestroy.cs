﻿using UnityEngine;
using System.Collections;

public class BarrierDestroy : MonoBehaviour
{

    private Transform findPlayer;

    void Start()
    {
        findPlayer = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Update()
    {
        if (transform.position.y < findPlayer.position.y - 25)
        {
            Destroy(gameObject);
        }
    }
}
