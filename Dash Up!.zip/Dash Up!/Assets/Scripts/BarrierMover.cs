﻿using UnityEngine;
using System.Collections;

public class BarrierMover : MonoBehaviour {

    public float minValue = -5.0f;
    public float maxValue = 5.0f;
    public float direction = 1.0f;
    public float speed = 10.0f;

    private float currentValue;
    private float xPos;

	void Start ()
    {
        xPos = transform.position.x;
	}
	
	void Update ()
    {
        currentValue = currentValue + (Time.deltaTime * direction * speed);

        if(currentValue >= maxValue)
        {
            direction = -1;
            currentValue = maxValue;
        }

        else if(currentValue <= minValue)
        {
            direction = 1;
            currentValue = minValue;
        }

        transform.position = new Vector2((xPos + currentValue), transform.position.y);
	}
}
