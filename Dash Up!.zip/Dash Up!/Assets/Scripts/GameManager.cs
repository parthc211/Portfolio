﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    public static GameManager instance;
    public Text pointsText;
    public bool over;
    public GameObject player;
    public GameObject spawner;
    public GameObject gameOver;
    public GameObject menuButton;
    public GameObject resumeButton;
    public GameObject restartButton;

	void Awake ()
    {
        if(instance == null)
        {
            instance = this;
        }
        else if(instance != null)
        {
            Destroy(gameObject);
        }
        init();
	}
	
    void init()
    {
        over = false;

        gameOver.SetActive(false);
        resumeButton.SetActive(false);
        restartButton.SetActive(false);
        menuButton.SetActive(true);
    }

    public void OnPause()
    {
        restartButton.SetActive(true);
        resumeButton.SetActive(true);
        menuButton.SetActive(false);

        Time.timeScale = 0;
    }

    public void OnResume()
    {
        restartButton.SetActive(false);
        resumeButton.SetActive(false);
        menuButton.SetActive(true);

        Time.timeScale = 1;
    }

    public void OnRestart()
    {
        Time.timeScale = 1;
        Application.LoadLevel(0);
    }

    public void GameOver()
    {
        Time.timeScale = 0;

        Destroy(player.gameObject);
        Destroy(spawner.gameObject);
        over = true;
        gameOver.SetActive(true);
        restartButton.SetActive(true);
    }

    public void SetPoints(int pts)
    {
        pointsText.text = "Points: " + pts;
    }
}
